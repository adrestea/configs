## Docker autocomplete plugin

A copy of the completion script from the
[docker](https://github.com/docker/docker/tree/master/contrib/completion/zsh)
git repo.
